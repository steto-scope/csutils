var searchData=
[
  ['itranslationprovider',['ITranslationProvider',['../interfacecsutils_1_1_globalisation_1_1_translation_provider_1_1_i_translation_provider.html',1,'csutils::Globalisation::TranslationProvider']]]
];
