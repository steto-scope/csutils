var searchData=
[
  ['xmltranslationprovider',['XmlTranslationProvider',['../classcsutils_1_1_globalisation_1_1_translation_provider_1_1_xml_translation_provider.html',1,'csutils::Globalisation::TranslationProvider']]]
];
