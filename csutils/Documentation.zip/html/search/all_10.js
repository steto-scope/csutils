var searchData=
[
  ['save',['Save',['../classcsutils_1_1_file_formats_1_1_i_n_i_1_1_ini_file.html#ac815c3b779943a056d5d14be3b479907',1,'csutils::FileFormats::INI::IniFile']]],
  ['sectioncount',['SectionCount',['../classcsutils_1_1_file_formats_1_1_i_n_i_1_1_ini_file.html#a194b54caa43c0bc390a19b8574ee7979',1,'csutils::FileFormats::INI::IniFile']]],
  ['sectionnames',['SectionNames',['../classcsutils_1_1_file_formats_1_1_i_n_i_1_1_ini_file.html#abf32c168c4161ba9c3a1ba7d9e815973',1,'csutils::FileFormats::INI::IniFile']]],
  ['sections',['Sections',['../classcsutils_1_1_file_formats_1_1_i_n_i_1_1_ini_file.html#aad22ffbc7fbecb9354028c67a4382468',1,'csutils::FileFormats::INI::IniFile']]],
  ['serializabledictionary',['SerializableDictionary',['../classcsutils_1_1_data_1_1_serializable_dictionary.html#abb4118c3dfd30a7e981398ffa29ec0a9',1,'csutils.Data.SerializableDictionary.SerializableDictionary()'],['../classcsutils_1_1_data_1_1_serializable_dictionary.html#a0efd8b38adc300cfd6c3750271d38ed2',1,'csutils.Data.SerializableDictionary.SerializableDictionary(int capacity)'],['../classcsutils_1_1_data_1_1_serializable_dictionary.html#a10c491cd576a412cea6b4933d9d0d86e',1,'csutils.Data.SerializableDictionary.SerializableDictionary(IEqualityComparer&lt; TKey &gt; comparer)'],['../classcsutils_1_1_data_1_1_serializable_dictionary.html#a8df239e2cc7a5fd600e0e16d750da165',1,'csutils.Data.SerializableDictionary.SerializableDictionary(IDictionary&lt; TKey, TValue &gt; dictionary)']]],
  ['serializabledictionary',['SerializableDictionary',['../classcsutils_1_1_data_1_1_serializable_dictionary.html',1,'csutils::Data']]],
  ['serializabledictionary_3c_20tuple_3c_20t1_2c_20t2_20_3e_2c_20t3_20_3e',['SerializableDictionary&lt; Tuple&lt; T1, T2 &gt;, T3 &gt;',['../classcsutils_1_1_data_1_1_serializable_dictionary.html',1,'csutils::Data']]],
  ['set',['Set',['../classcsutils_1_1_data_1_1_base.html#ae7b133cd1f72629b7662314ae272ac61',1,'csutils::Data::Base']]],
  ['setproperty',['SetProperty',['../classcsutils_1_1_data_1_1_base.html#a39383c86cceff6e6ec09e7b7c2b007d1',1,'csutils::Data::Base']]],
  ['startlistening',['StartListening',['../classcsutils_1_1_globalisation_1_1_language_changed_event_manager.html#aa7cef84045026a8d1609fb8adc75537e',1,'csutils::Globalisation::LanguageChangedEventManager']]],
  ['stoplistening',['StopListening',['../classcsutils_1_1_globalisation_1_1_language_changed_event_manager.html#aa71dac5ec9faa2754624f346856dc641',1,'csutils::Globalisation::LanguageChangedEventManager']]],
  ['system',['System',['../namespace_system.html',1,'']]]
];
