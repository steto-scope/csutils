var searchData=
[
  ['installedtranslations',['InstalledTranslations',['../classcsutils_1_1_globalisation_1_1_translation_manager.html#ae3c442596be7e30f328e914714507381',1,'csutils::Globalisation::TranslationManager']]]
];
