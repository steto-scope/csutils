var searchData=
[
  ['count',['Count',['../classcsutils_1_1_file_formats_1_1_i_n_i_1_1_ini_section.html#abfce6b151230a806d877384aaabfe7ff',1,'csutils::FileFormats::INI::IniSection']]],
  ['currentculture',['CurrentCulture',['../classcsutils_1_1_globalisation_1_1_translation_manager.html#ac543585a966a4abd4f34fe1e5f5cdb6f',1,'csutils::Globalisation::TranslationManager']]]
];
