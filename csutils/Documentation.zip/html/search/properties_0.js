var searchData=
[
  ['currentculture',['CurrentCulture',['../classcsutils_1_1_globalisation_1_1_translation_manager.html#ac543585a966a4abd4f34fe1e5f5cdb6f',1,'csutils::Globalisation::TranslationManager']]]
];
