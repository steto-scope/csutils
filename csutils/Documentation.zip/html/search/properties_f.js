var searchData=
[
  ['value',['Value',['../classcsutils_1_1_globalisation_1_1_translation_data.html#ad784440bd887a6c310450df32b2e760a',1,'csutils::Globalisation::TranslationData']]],
  ['valueattributename',['ValueAttributeName',['../classcsutils_1_1_globalisation_1_1_translation_provider_1_1_xml_translation_provider.html#a78e495c99592b87a14037aaf153fa28c',1,'csutils::Globalisation::TranslationProvider::XmlTranslationProvider']]],
  ['values',['Values',['../classcsutils_1_1_file_formats_1_1_i_n_i_1_1_ini_section.html#a1c372c1ea3ba3786a4ac9b94592cbab4',1,'csutils::FileFormats::INI::IniSection']]]
];
