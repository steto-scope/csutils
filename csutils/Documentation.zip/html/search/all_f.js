var searchData=
[
  ['quotations',['Quotations',['../namespace_system.html#a65db50b8fccc893fbf62c4f942ecbb04aeb8f9a9ec38815aa8ed81682de0c6e18',1,'System']]],
  ['quotesregex',['QuotesRegex',['../classcsutils_1_1_data_1_1_regexes.html#a86a3c5a8861c0b51ebb20f777f5f82dc',1,'csutils::Data::Regexes']]]
];
