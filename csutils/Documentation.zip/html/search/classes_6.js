var searchData=
[
  ['serializabledictionary',['SerializableDictionary',['../classcsutils_1_1_data_1_1_serializable_dictionary.html',1,'csutils::Data']]],
  ['serializabledictionary_3c_20keyvaluepair_3c_20t1_2c_20t2_20_3e_2c_20t3_20_3e',['SerializableDictionary&lt; KeyValuePair&lt; T1, T2 &gt;, T3 &gt;',['../classcsutils_1_1_data_1_1_serializable_dictionary.html',1,'csutils::Data']]],
  ['serializablestringdictionary',['SerializableStringDictionary',['../classcsutils_1_1_data_1_1_serializable_string_dictionary.html',1,'csutils::Data']]],
  ['serializablestringdictionary_3c_20object_20_3e',['SerializableStringDictionary&lt; object &gt;',['../classcsutils_1_1_data_1_1_serializable_string_dictionary.html',1,'csutils::Data']]],
  ['shenanigans',['Shenanigans',['../classcsutils_1_1_cryptography_1_1_shenanigans.html',1,'csutils::Cryptography']]]
];
