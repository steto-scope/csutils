var searchData=
[
  ['inifile',['IniFile',['../classcsutils_1_1_file_formats_1_1_i_n_i_1_1_ini_file.html#af028c31649bbcb0d5480399186758baa',1,'csutils.FileFormats.INI.IniFile.IniFile()'],['../classcsutils_1_1_file_formats_1_1_i_n_i_1_1_ini_file.html#a0956a3e7238428896d1b2b12b54ed4aa',1,'csutils.FileFormats.INI.IniFile.IniFile(Stream s)'],['../classcsutils_1_1_file_formats_1_1_i_n_i_1_1_ini_file.html#a3233a2eeaf38cc245a21e84eeed26fb6',1,'csutils.FileFormats.INI.IniFile.IniFile(string content)']]],
  ['inisection',['IniSection',['../classcsutils_1_1_file_formats_1_1_i_n_i_1_1_ini_section.html#ac7261723383d994298e5745d64c2e185',1,'csutils.FileFormats.INI.IniSection.IniSection()'],['../classcsutils_1_1_file_formats_1_1_i_n_i_1_1_ini_section.html#a5df695ffa538600cce96c3f4bf8f6f90',1,'csutils.FileFormats.INI.IniSection.IniSection(string name)']]],
  ['installedtranslations',['InstalledTranslations',['../classcsutils_1_1_globalisation_1_1_translation_manager.html#ae3c442596be7e30f328e914714507381',1,'csutils::Globalisation::TranslationManager']]]
];
