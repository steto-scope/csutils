var searchData=
[
  ['downloadprogress',['DownloadProgress',['../interfacecsutils_1_1_downloader_1_1_i_downloader.html#a0d8ca03bf6c5e79992ec54c2b9e899fc',1,'csutils::Downloader::IDownloader']]]
];
