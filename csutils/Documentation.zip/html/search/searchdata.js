var indexSectionsWithContent =
{
  0: "abcdefghiklmnopqrstuvwx",
  1: "bcdilrstx",
  2: "cs",
  3: "acdefgilmoprstwx",
  4: "ev",
  5: "cdim",
  6: "acdeimnopqrsuwx",
  7: "abcdehiklmnopqrstuvx",
  8: "cdlp"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "properties",
  8: "events"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Properties",
  8: "Events"
};

