var indexSectionsWithContent =
{
  0: "abcdefghiklmnopqrstuvwx",
  1: "bdilrstx",
  2: "cs",
  3: "acdefgiloprstwx",
  4: "v",
  5: "cdi",
  6: "acdeimnpqrsuwx",
  7: "bcdehikmnpqrstvx",
  8: "dlp"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "properties",
  8: "events"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Properties",
  8: "Events"
};

