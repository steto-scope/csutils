var searchData=
[
  ['dispose',['Dispose',['../classcsutils_1_1_downloader_1_1_throttled_stream.html#afb654b1814e89ec7414a67c56fa6fbaf',1,'csutils.Downloader.ThrottledStream.Dispose()'],['../classcsutils_1_1_globalisation_1_1_translation_data.html#a7184359c9ef8575940870c7b150d723a',1,'csutils.Globalisation.TranslationData.Dispose()'],['../classcsutils_1_1_globalisation_1_1_translation_data.html#a9814179553e2239be7581980077c2f2e',1,'csutils.Globalisation.TranslationData.Dispose(bool disposing)']]],
  ['downloadmanager',['DownloadManager',['../classcsutils_1_1_downloader_1_1_download_manager.html#a78503f214a54f5a6ce10c4cccc039a03',1,'csutils.Downloader.DownloadManager.DownloadManager(IEnumerable&lt; string &gt; sources)'],['../classcsutils_1_1_downloader_1_1_download_manager.html#ada1f5198dcb2a51f8c9a0ef389f870db',1,'csutils.Downloader.DownloadManager.DownloadManager(IEnumerable&lt; IDownloader &gt; downloaders)']]],
  ['downloadprogresseventargs',['DownloadProgressEventArgs',['../classcsutils_1_1_downloader_1_1_download_progress_event_args.html#af021031e183df1f6c63fe1d7dd2aa56e',1,'csutils::Downloader::DownloadProgressEventArgs']]]
];
