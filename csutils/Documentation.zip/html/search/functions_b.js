var searchData=
[
  ['save',['Save',['../classcsutils_1_1_file_formats_1_1_i_n_i_1_1_ini_file.html#ac815c3b779943a056d5d14be3b479907',1,'csutils::FileFormats::INI::IniFile']]],
  ['serializabledictionary',['SerializableDictionary',['../classcsutils_1_1_data_1_1_serializable_dictionary.html#abb4118c3dfd30a7e981398ffa29ec0a9',1,'csutils.Data.SerializableDictionary.SerializableDictionary()'],['../classcsutils_1_1_data_1_1_serializable_dictionary.html#a0efd8b38adc300cfd6c3750271d38ed2',1,'csutils.Data.SerializableDictionary.SerializableDictionary(int capacity)'],['../classcsutils_1_1_data_1_1_serializable_dictionary.html#a10c491cd576a412cea6b4933d9d0d86e',1,'csutils.Data.SerializableDictionary.SerializableDictionary(IEqualityComparer&lt; TKey &gt; comparer)'],['../classcsutils_1_1_data_1_1_serializable_dictionary.html#a8df239e2cc7a5fd600e0e16d750da165',1,'csutils.Data.SerializableDictionary.SerializableDictionary(IDictionary&lt; TKey, TValue &gt; dictionary)']]],
  ['set',['Set',['../classcsutils_1_1_data_1_1_base.html#ae7b133cd1f72629b7662314ae272ac61',1,'csutils::Data::Base']]],
  ['setproperty',['SetProperty',['../classcsutils_1_1_data_1_1_base.html#a39383c86cceff6e6ec09e7b7c2b007d1',1,'csutils::Data::Base']]],
  ['start',['Start',['../interfacecsutils_1_1_downloader_1_1_i_downloader.html#a7fd53c74bda39e354ba754502bf13a1c',1,'csutils::Downloader::IDownloader']]],
  ['startasync',['StartAsync',['../interfacecsutils_1_1_downloader_1_1_i_downloader.html#ad4740bf194f9406cbe7a535f3588eef5',1,'csutils::Downloader::IDownloader']]],
  ['startlistening',['StartListening',['../classcsutils_1_1_globalisation_1_1_language_changed_event_manager.html#aa7cef84045026a8d1609fb8adc75537e',1,'csutils::Globalisation::LanguageChangedEventManager']]],
  ['stoplistening',['StopListening',['../classcsutils_1_1_globalisation_1_1_language_changed_event_manager.html#aa71dac5ec9faa2754624f346856dc641',1,'csutils::Globalisation::LanguageChangedEventManager']]]
];
