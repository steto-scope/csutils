var searchData=
[
  ['xmltranslationprovider',['XmlTranslationProvider',['../classcsutils_1_1_globalisation_1_1_translation_provider_1_1_xml_translation_provider.html#a43d9596a80ec7ecb8bc3f75f0dbd98a1',1,'csutils::Globalisation::TranslationProvider::XmlTranslationProvider']]]
];
