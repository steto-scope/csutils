var searchData=
[
  ['languagechangedeventmanager',['LanguageChangedEventManager',['../classcsutils_1_1_globalisation_1_1_language_changed_event_manager.html',1,'csutils::Globalisation']]]
];
