var searchData=
[
  ['bandwidthlimit',['BandwidthLimit',['../classcsutils_1_1_downloader_1_1_download_manager.html#a34ec7adb83b7e232e9a8e82bcebc0ca3',1,'csutils.Downloader.DownloadManager.BandwidthLimit()'],['../interfacecsutils_1_1_downloader_1_1_i_downloader.html#a5a43dd1f1e1bd10cabb5e2d21db3a2ed',1,'csutils.Downloader.IDownloader.BandwidthLimit()'],['../classcsutils_1_1_downloader_1_1_throttled_stream.html#a72e16d5dc3919b634b5e4c2f216469e0',1,'csutils.Downloader.ThrottledStream.BandwidthLimit()']]],
  ['bytes',['Bytes',['../classcsutils_1_1_downloader_1_1_download_progress_event_args.html#a67261a22eff80e1a416d2f4fd0674eae',1,'csutils::Downloader::DownloadProgressEventArgs']]]
];
