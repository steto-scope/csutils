var searchData=
[
  ['defaultculture',['DefaultCulture',['../classcsutils_1_1_globalisation_1_1_translation_manager.html#ab3a76e9697ec45dac3c0330fcf19d101',1,'csutils::Globalisation::TranslationManager']]]
];
