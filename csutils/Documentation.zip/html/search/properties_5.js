var searchData=
[
  ['this_5bt1_20key1_2c_20t2_20key2_5d',['this[T1 key1, T2 key2]',['../classcsutils_1_1_data_1_1_two_key_dictionary.html#a2af214c430a47f3cf7ee710ea87bd09f',1,'csutils::Data::TwoKeyDictionary']]],
  ['translationproviderfactory',['TranslationProviderFactory',['../classcsutils_1_1_globalisation_1_1_translation_manager.html#a7b64262f601834e9bcd2ed7dd570db7f',1,'csutils::Globalisation::TranslationManager']]]
];
