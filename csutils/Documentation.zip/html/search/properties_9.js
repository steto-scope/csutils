var searchData=
[
  ['pending',['Pending',['../classcsutils_1_1_downloader_1_1_download_manager.html#af1a774ebd22dc4bb118f1bdbe70ebdc0',1,'csutils::Downloader::DownloadManager']]],
  ['percentage',['Percentage',['../interfacecsutils_1_1_downloader_1_1_i_downloader.html#a6bbe0c149706bf1c871f1df26b86503a',1,'csutils::Downloader::IDownloader']]]
];
