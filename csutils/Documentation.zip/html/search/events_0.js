var searchData=
[
  ['completed',['Completed',['../classcsutils_1_1_downloader_1_1_download_manager.html#adb9bbf2aefda31c97827b3b01b4bbea1',1,'csutils::Downloader::DownloadManager']]]
];
