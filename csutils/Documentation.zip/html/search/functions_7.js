var searchData=
[
  ['load',['Load',['../classcsutils_1_1_file_formats_1_1_i_n_i_1_1_ini_file.html#aecf60967dedd9226228197b4beb45641',1,'csutils.FileFormats.INI.IniFile.Load(string content)'],['../classcsutils_1_1_file_formats_1_1_i_n_i_1_1_ini_file.html#a58c2a14ae781dedda05416941ff41e0f',1,'csutils.FileFormats.INI.IniFile.Load(string content, IniFileLoadStrategy strategy)']]]
];
