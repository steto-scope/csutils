var searchData=
[
  ['inisections',['IniSections',['../classcsutils_1_1_file_formats_1_1_i_n_i_1_1_ini_file.html#aa71f5b21d7a07ec1fe86859df0baa0c0',1,'csutils::FileFormats::INI::IniFile']]],
  ['invaliduricharacterregex',['InvalidUriCharacterRegex',['../classcsutils_1_1_data_1_1_regexes.html#a1a8625d23a201c3fb1721005d0d25c4a',1,'csutils::Data::Regexes']]],
  ['iscompleted',['IsCompleted',['../interfacecsutils_1_1_downloader_1_1_i_downloader.html#a302df26ebe0e9482ef4626d244fb8e82',1,'csutils::Downloader::IDownloader']]],
  ['isdownloading',['IsDownloading',['../classcsutils_1_1_downloader_1_1_download_manager.html#a4345c472250d8ddd405ebe3cd2627761',1,'csutils.Downloader.DownloadManager.IsDownloading()'],['../interfacecsutils_1_1_downloader_1_1_i_downloader.html#a1f1a1cae4146b67096aae2d882f0ef7f',1,'csutils.Downloader.IDownloader.IsDownloading()']]]
];
