var searchData=
[
  ['value',['Value',['../classcsutils_1_1_globalisation_1_1_translation_data.html#ad784440bd887a6c310450df32b2e760a',1,'csutils::Globalisation::TranslationData']]],
  ['valueattributename',['ValueAttributeName',['../classcsutils_1_1_globalisation_1_1_translation_provider_1_1_xml_translation_provider.html#a78e495c99592b87a14037aaf153fa28c',1,'csutils::Globalisation::TranslationProvider::XmlTranslationProvider']]]
];
