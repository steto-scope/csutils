var searchData=
[
  ['clear',['Clear',['../classcsutils_1_1_globalisation_1_1_translation_manager.html#a8b8add7dedc29e61f281e2f75131689b',1,'csutils::Globalisation::TranslationManager']]],
  ['clone',['Clone',['../classcsutils_1_1_data_1_1_base.html#a38a412e972f53c181691f1b7232286eb',1,'csutils.Data.Base.Clone()'],['../classcsutils_1_1_downloader_1_1_download_manager.html#a35959d2d334903438fab0edeafd51363',1,'csutils.Downloader.DownloadManager.Clone()']]],
  ['clone_3c_20t_20_3e',['Clone&lt; T &gt;',['../classcsutils_1_1_configuration_1_1_config_base.html#a37681043fb7a10fd99d243a50e220813',1,'csutils.Configuration.ConfigBase.Clone&lt; T &gt;()'],['../classcsutils_1_1_data_1_1_base.html#ae42903eceedc05c6acff02af537a1018',1,'csutils.Data.Base.Clone&lt; T &gt;()']]],
  ['close',['Close',['../classcsutils_1_1_downloader_1_1_throttled_stream.html#a4f56e8ff6697185ec93fdaad4936f7dd',1,'csutils::Downloader::ThrottledStream']]],
  ['configbase',['ConfigBase',['../classcsutils_1_1_configuration_1_1_config_base.html#a184ab28834dc366f16fa3d0746b8c4e3',1,'csutils::Configuration::ConfigBase']]],
  ['configchangedeventargs',['ConfigChangedEventArgs',['../classcsutils_1_1_configuration_1_1_config_changed_event_args.html#ad7402fe36c17588dbfb595852b721638',1,'csutils::Configuration::ConfigChangedEventArgs']]],
  ['containskey',['ContainsKey',['../classcsutils_1_1_data_1_1_two_key_dictionary.html#a2e0c02d60f171149bb2dc77389902cac',1,'csutils::Data::TwoKeyDictionary']]],
  ['containskey1',['ContainsKey1',['../classcsutils_1_1_data_1_1_two_key_dictionary.html#ab0ff6fa93711b81441f0e8264d297b14',1,'csutils::Data::TwoKeyDictionary']]],
  ['containskey2',['ContainsKey2',['../classcsutils_1_1_data_1_1_two_key_dictionary.html#a16779dadba1c28df5f48eccbac9b4f74',1,'csutils::Data::TwoKeyDictionary']]],
  ['create',['Create',['../classcsutils_1_1_globalisation_1_1_translation_provider_factory.html#a5e413610434606b37f139705021e69ee',1,'csutils.Globalisation.TranslationProviderFactory.Create(FileInfo file)'],['../classcsutils_1_1_globalisation_1_1_translation_provider_factory.html#a8a32eef3dc22e51b138f4ec7c09d6ea7',1,'csutils.Globalisation.TranslationProviderFactory.Create(string extension)']]],
  ['createdownloader',['CreateDownloader',['../classcsutils_1_1_downloader_1_1_downloader_factory.html#a74b0038afc5acfb32221eff961a21066',1,'csutils.Downloader.DownloaderFactory.CreateDownloader(string path, Stream target=null, ICredentials credentials=null)'],['../classcsutils_1_1_downloader_1_1_downloader_factory.html#ac3442de6f097e2856aefa89dfdfa09fc',1,'csutils.Downloader.DownloaderFactory.CreateDownloader(string path, string target, ICredentials credentials=null)']]]
];
