var searchData=
[
  ['xmltagregex',['XMLTagRegex',['../classcsutils_1_1_data_1_1_regexes.html#a390cfcb7df7766561ef3d182000fe64b',1,'csutils::Data::Regexes']]]
];
