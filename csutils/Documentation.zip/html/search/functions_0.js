var searchData=
[
  ['add',['Add',['../classcsutils_1_1_data_1_1_two_key_dictionary.html#a26e274ad005b26b29a433b2dc5cb973a',1,'csutils.Data.TwoKeyDictionary.Add()'],['../classcsutils_1_1_globalisation_1_1_translation_manager.html#a6a399183f7f10507d89434f3b23e801f',1,'csutils.Globalisation.TranslationManager.Add(string file, CultureInfo culture=null, string channel=&quot;&quot;)'],['../classcsutils_1_1_globalisation_1_1_translation_manager.html#aff7e0e1d41b31bef86071c38513fac32',1,'csutils.Globalisation.TranslationManager.Add(Stream stream, string extension, CultureInfo culture, string channel=&quot;&quot;)']]],
  ['addlistener',['AddListener',['../classcsutils_1_1_globalisation_1_1_language_changed_event_manager.html#a537d943ac3db4d791ebf6619f7caaa18',1,'csutils::Globalisation::LanguageChangedEventManager']]]
];
