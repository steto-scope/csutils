var searchData=
[
  ['abort',['Abort',['../classcsutils_1_1_downloader_1_1_download_manager.html#a51af72d7b5d2f77661f8e552cdb57b53',1,'csutils.Downloader.DownloadManager.Abort()'],['../interfacecsutils_1_1_downloader_1_1_i_downloader.html#a02807a91f582361425423e982e37f8a1',1,'csutils.Downloader.IDownloader.Abort()']]],
  ['add',['Add',['../classcsutils_1_1_data_1_1_two_key_dictionary.html#a26e274ad005b26b29a433b2dc5cb973a',1,'csutils.Data.TwoKeyDictionary.Add()'],['../classcsutils_1_1_globalisation_1_1_translation_manager.html#a6a399183f7f10507d89434f3b23e801f',1,'csutils.Globalisation.TranslationManager.Add(string file, CultureInfo culture=null, string channel=&quot;&quot;)'],['../classcsutils_1_1_globalisation_1_1_translation_manager.html#aff7e0e1d41b31bef86071c38513fac32',1,'csutils.Globalisation.TranslationManager.Add(Stream stream, string extension, CultureInfo culture, string channel=&quot;&quot;)']]],
  ['addfromdirectory',['AddFromDirectory',['../classcsutils_1_1_globalisation_1_1_translation_manager.html#aac9758f11f315d53aaa859f70b49dcb4',1,'csutils::Globalisation::TranslationManager']]],
  ['addlistener',['AddListener',['../classcsutils_1_1_globalisation_1_1_language_changed_event_manager.html#a537d943ac3db4d791ebf6619f7caaa18',1,'csutils::Globalisation::LanguageChangedEventManager']]]
];
