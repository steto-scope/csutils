var searchData=
[
  ['propertychanged',['PropertyChanged',['../classcsutils_1_1_data_1_1_base.html#aa91e373cc302a48eff93e44e74201a10',1,'csutils.Data.Base.PropertyChanged()'],['../classcsutils_1_1_data_1_1_unique_list.html#a2c2dd78602d2e1c834de016114dd2d34',1,'csutils.Data.UniqueList.PropertyChanged()'],['../classcsutils_1_1_globalisation_1_1_translation_data.html#a11d94edd91d2fdef8f94716000332383',1,'csutils.Globalisation.TranslationData.PropertyChanged()']]]
];
