var searchData=
[
  ['gigabyte',['Gigabyte',['../namespace_system.html#ab556721453b252a5cd7b8069d9055431a216c9b2bcd6ad84ac05cc369bb629a8b',1,'System']]]
];
