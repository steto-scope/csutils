var searchData=
[
  ['oldvalue',['OldValue',['../classcsutils_1_1_configuration_1_1_config_changed_event_args.html#a8e349c8a1b3aaa37348fee10efee3f4b',1,'csutils::Configuration::ConfigChangedEventArgs']]]
];
