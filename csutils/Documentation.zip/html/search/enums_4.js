var searchData=
[
  ['inifileloadstrategy',['IniFileLoadStrategy',['../namespacecsutils_1_1_file_formats_1_1_i_n_i.html#a90f67adf6028e2ff35f938b7d175487a',1,'csutils::FileFormats::INI']]]
];
