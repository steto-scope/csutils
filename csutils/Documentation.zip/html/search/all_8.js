var searchData=
[
  ['idownloader',['IDownloader',['../interfacecsutils_1_1_downloader_1_1_i_downloader.html',1,'csutils::Downloader']]],
  ['inactive',['Inactive',['../namespacecsutils_1_1_downloader.html#a3a444f1622866337e6a2577b1bd2d388a3cab03c00dbd11bc3569afa0748013f0',1,'csutils::Downloader']]],
  ['inifile',['IniFile',['../classcsutils_1_1_file_formats_1_1_i_n_i_1_1_ini_file.html',1,'csutils::FileFormats::INI']]],
  ['inifile',['IniFile',['../classcsutils_1_1_file_formats_1_1_i_n_i_1_1_ini_file.html#af028c31649bbcb0d5480399186758baa',1,'csutils.FileFormats.INI.IniFile.IniFile()'],['../classcsutils_1_1_file_formats_1_1_i_n_i_1_1_ini_file.html#a0956a3e7238428896d1b2b12b54ed4aa',1,'csutils.FileFormats.INI.IniFile.IniFile(Stream s)'],['../classcsutils_1_1_file_formats_1_1_i_n_i_1_1_ini_file.html#a3233a2eeaf38cc245a21e84eeed26fb6',1,'csutils.FileFormats.INI.IniFile.IniFile(string content)']]],
  ['inifileloadstrategy',['IniFileLoadStrategy',['../namespacecsutils_1_1_file_formats_1_1_i_n_i.html#a90f67adf6028e2ff35f938b7d175487a',1,'csutils::FileFormats::INI']]],
  ['iniparser',['IniParser',['../classcsutils_1_1_file_formats_1_1_i_n_i_1_1_ini_parser.html',1,'csutils::FileFormats::INI']]],
  ['inisection',['IniSection',['../classcsutils_1_1_file_formats_1_1_i_n_i_1_1_ini_section.html',1,'csutils::FileFormats::INI']]],
  ['inisection',['IniSection',['../classcsutils_1_1_file_formats_1_1_i_n_i_1_1_ini_section.html#ac7261723383d994298e5745d64c2e185',1,'csutils.FileFormats.INI.IniSection.IniSection()'],['../classcsutils_1_1_file_formats_1_1_i_n_i_1_1_ini_section.html#a5df695ffa538600cce96c3f4bf8f6f90',1,'csutils.FileFormats.INI.IniSection.IniSection(string name)']]],
  ['inisections',['IniSections',['../classcsutils_1_1_file_formats_1_1_i_n_i_1_1_ini_file.html#aa71f5b21d7a07ec1fe86859df0baa0c0',1,'csutils::FileFormats::INI::IniFile']]],
  ['installedtranslations',['InstalledTranslations',['../classcsutils_1_1_globalisation_1_1_translation_manager.html#ae3c442596be7e30f328e914714507381',1,'csutils::Globalisation::TranslationManager']]],
  ['invalidpathcharacters',['InvalidPathCharacters',['../namespace_system.html#a65db50b8fccc893fbf62c4f942ecbb04a15c8dadc9fefc166a67a1436d57e4299',1,'System']]],
  ['invaliduricharacterregex',['InvalidUriCharacterRegex',['../classcsutils_1_1_data_1_1_regexes.html#a1a8625d23a201c3fb1721005d0d25c4a',1,'csutils::Data::Regexes']]],
  ['invalidurlcharacters',['InvalidURLCharacters',['../namespace_system.html#a65db50b8fccc893fbf62c4f942ecbb04a7184ab95bfc0187d45819af214caadbe',1,'System']]],
  ['iscompleted',['IsCompleted',['../interfacecsutils_1_1_downloader_1_1_i_downloader.html#a302df26ebe0e9482ef4626d244fb8e82',1,'csutils::Downloader::IDownloader']]],
  ['isdownloading',['IsDownloading',['../interfacecsutils_1_1_downloader_1_1_i_downloader.html#a1f1a1cae4146b67096aae2d882f0ef7f',1,'csutils::Downloader::IDownloader']]],
  ['itranslationprovider',['ITranslationProvider',['../interfacecsutils_1_1_globalisation_1_1_translation_provider_1_1_i_translation_provider.html',1,'csutils::Globalisation::TranslationProvider']]]
];
