var searchData=
[
  ['regexes',['Regexes',['../classcsutils_1_1_data_1_1_regexes.html',1,'csutils::Data']]]
];
