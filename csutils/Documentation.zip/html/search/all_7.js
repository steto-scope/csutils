var searchData=
[
  ['hasunknownfilesize',['HasUnknownFilesize',['../interfacecsutils_1_1_downloader_1_1_i_downloader.html#a2d563bc93b7b8c35f2679245d0151e4a',1,'csutils::Downloader::IDownloader']]]
];
