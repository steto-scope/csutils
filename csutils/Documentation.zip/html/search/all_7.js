var searchData=
[
  ['languagechanged',['LanguageChanged',['../classcsutils_1_1_globalisation_1_1_translation_manager.html#a07b61b7d17cd302e9337f1ae728fafab',1,'csutils::Globalisation::TranslationManager']]],
  ['languagechangedeventmanager',['LanguageChangedEventManager',['../classcsutils_1_1_globalisation_1_1_language_changed_event_manager.html',1,'csutils::Globalisation']]]
];
