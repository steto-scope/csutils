var searchData=
[
  ['whitespaces',['Whitespaces',['../namespace_system.html#a65db50b8fccc893fbf62c4f942ecbb04affeaae637d363e4ff033463b6f3d4da8',1,'System']]]
];
