var searchData=
[
  ['defaultculture',['DefaultCulture',['../classcsutils_1_1_globalisation_1_1_translation_manager.html#ab3a76e9697ec45dac3c0330fcf19d101',1,'csutils::Globalisation::TranslationManager']]],
  ['dispose',['Dispose',['../classcsutils_1_1_downloader_1_1_throttled_stream.html#afb654b1814e89ec7414a67c56fa6fbaf',1,'csutils.Downloader.ThrottledStream.Dispose()'],['../classcsutils_1_1_globalisation_1_1_translation_data.html#a7184359c9ef8575940870c7b150d723a',1,'csutils.Globalisation.TranslationData.Dispose()'],['../classcsutils_1_1_globalisation_1_1_translation_data.html#a9814179553e2239be7581980077c2f2e',1,'csutils.Globalisation.TranslationData.Dispose(bool disposing)']]],
  ['downloadedbytes',['DownloadedBytes',['../classcsutils_1_1_downloader_1_1_download_manager.html#a870e58a69f0b2e8692ded0c2869a6a27',1,'csutils.Downloader.DownloadManager.DownloadedBytes()'],['../interfacecsutils_1_1_downloader_1_1_i_downloader.html#ac5871f5e8f331c4cba7e0777a769581e',1,'csutils.Downloader.IDownloader.DownloadedBytes()']]],
  ['downloaderfactory',['DownloaderFactory',['../classcsutils_1_1_downloader_1_1_downloader_factory.html',1,'csutils::Downloader']]],
  ['downloaderstate',['DownloaderState',['../interfacecsutils_1_1_downloader_1_1_i_downloader.html#af8ab51e5a068186dddd3830b2454f0d2',1,'csutils::Downloader::IDownloader']]],
  ['downloading',['Downloading',['../namespacecsutils_1_1_downloader.html#a3a444f1622866337e6a2577b1bd2d388ac7e71badf20a04f36d11be557ceb7a5b',1,'csutils::Downloader']]],
  ['downloadmanager',['DownloadManager',['../classcsutils_1_1_downloader_1_1_download_manager.html#a78503f214a54f5a6ce10c4cccc039a03',1,'csutils.Downloader.DownloadManager.DownloadManager(IEnumerable&lt; string &gt; sources)'],['../classcsutils_1_1_downloader_1_1_download_manager.html#ada1f5198dcb2a51f8c9a0ef389f870db',1,'csutils.Downloader.DownloadManager.DownloadManager(IEnumerable&lt; IDownloader &gt; downloaders)']]],
  ['downloadmanager',['DownloadManager',['../classcsutils_1_1_downloader_1_1_download_manager.html',1,'csutils::Downloader']]],
  ['downloadprogress',['DownloadProgress',['../interfacecsutils_1_1_downloader_1_1_i_downloader.html#a0d8ca03bf6c5e79992ec54c2b9e899fc',1,'csutils::Downloader::IDownloader']]],
  ['downloadprogresseventargs',['DownloadProgressEventArgs',['../classcsutils_1_1_downloader_1_1_download_progress_event_args.html#af021031e183df1f6c63fe1d7dd2aa56e',1,'csutils::Downloader::DownloadProgressEventArgs']]],
  ['downloadprogresseventargs',['DownloadProgressEventArgs',['../classcsutils_1_1_downloader_1_1_download_progress_event_args.html',1,'csutils::Downloader']]],
  ['downloads',['Downloads',['../classcsutils_1_1_downloader_1_1_download_manager.html#ad2a92c406795edcd858c38d3bd54b4de',1,'csutils::Downloader::DownloadManager']]],
  ['downloadstate',['DownloadState',['../namespacecsutils_1_1_downloader.html#a3a444f1622866337e6a2577b1bd2d388',1,'csutils::Downloader']]],
  ['dummydata',['DummyData',['../classcsutils_1_1_data_1_1_dummy_data.html',1,'csutils::Data']]]
];
