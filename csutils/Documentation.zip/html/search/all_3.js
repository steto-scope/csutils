var searchData=
[
  ['defaultculture',['DefaultCulture',['../classcsutils_1_1_globalisation_1_1_translation_manager.html#ab3a76e9697ec45dac3c0330fcf19d101',1,'csutils::Globalisation::TranslationManager']]],
  ['dispose',['Dispose',['../classcsutils_1_1_globalisation_1_1_translation_data.html#a7184359c9ef8575940870c7b150d723a',1,'csutils.Globalisation.TranslationData.Dispose()'],['../classcsutils_1_1_globalisation_1_1_translation_data.html#a9814179553e2239be7581980077c2f2e',1,'csutils.Globalisation.TranslationData.Dispose(bool disposing)']]]
];
