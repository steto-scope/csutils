var searchData=
[
  ['quotations',['Quotations',['../namespace_system.html#a65db50b8fccc893fbf62c4f942ecbb04aeb8f9a9ec38815aa8ed81682de0c6e18',1,'System']]]
];
