var searchData=
[
  ['xmltagregex',['XMLTagRegex',['../classcsutils_1_1_data_1_1_regexes.html#a390cfcb7df7766561ef3d182000fe64b',1,'csutils::Data::Regexes']]],
  ['xmltags',['XMLTags',['../namespace_system.html#ac95508d9d397ca96bac8f84b4a4dabf7af61d2e3478504e5b5f67235f4fe0d028',1,'System']]]
];
