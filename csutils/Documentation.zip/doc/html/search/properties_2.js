var searchData=
[
  ['quotesregex',['QuotesRegex',['../classcsutils_1_1_data_1_1_regexes.html#a86a3c5a8861c0b51ebb20f777f5f82dc',1,'csutils::Data::Regexes']]]
];
