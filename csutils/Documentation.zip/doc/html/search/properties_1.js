var searchData=
[
  ['nonasciicharacterregex',['NonASCIICharacterRegex',['../classcsutils_1_1_data_1_1_regexes.html#a51b6a01fb8b41455a0735b0ce28cec45',1,'csutils::Data::Regexes']]]
];
