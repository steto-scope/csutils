var searchData=
[
  ['propertychanged',['PropertyChanged',['../classcsutils_1_1_data_1_1_base.html#aa91e373cc302a48eff93e44e74201a10',1,'csutils::Data::Base']]]
];
