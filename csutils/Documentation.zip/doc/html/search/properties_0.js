var searchData=
[
  ['invaliduricharacterregex',['InvalidUriCharacterRegex',['../classcsutils_1_1_data_1_1_regexes.html#a1a8625d23a201c3fb1721005d0d25c4a',1,'csutils::Data::Regexes']]]
];
