var indexSectionsWithContent =
{
  0: "cinqrswx",
  1: "r",
  2: "cs",
  3: "c",
  4: "inqwx",
  5: "inqx"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "enums",
  4: "enumvalues",
  5: "properties"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Enumerations",
  4: "Enumerator",
  5: "Properties"
};

