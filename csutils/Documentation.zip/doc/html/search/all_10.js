var searchData=
[
  ['whitespaces',['Whitespaces',['../namespace_system.html#a65db50b8fccc893fbf62c4f942ecbb04affeaae637d363e4ff033463b6f3d4da8',1,'System']]],
  ['writexml',['WriteXml',['../classcsutils_1_1_data_1_1_serializable_dictionary.html#af03cead1448cb13bc78cdb37855c3796',1,'csutils::Data::SerializableDictionary']]]
];
