var searchData=
[
  ['onpropertychanged',['OnPropertyChanged',['../classcsutils_1_1_data_1_1_base.html#a64b499547baa958dddae73b752aa0613',1,'csutils::Data::Base']]]
];
